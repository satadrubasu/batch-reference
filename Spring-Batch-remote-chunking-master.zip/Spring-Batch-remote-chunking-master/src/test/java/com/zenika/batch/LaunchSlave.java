/**
 * 
 */
package com.zenika.batch;

/**
 * @author acogoluegnes
 *
 */
public class LaunchSlave {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		
	}

}
