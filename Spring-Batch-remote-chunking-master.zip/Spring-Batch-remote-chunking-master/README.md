Spring-Batch-remote-chunking
============================

Spring Batch remote chunking code samples